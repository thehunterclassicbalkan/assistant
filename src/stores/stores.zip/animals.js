import { ref, computed } from 'vue'
import { defineStore } from 'pinia'

export const useStoreAnimals = defineStore('animals', () => {
  const animals = ref([
    {
      id: 'an1',
      name: 'Alpine ibex',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/5/5b/Alpine_ibex_male_common.png',
    },
    {
      id: 'an2',
      name: 'American Black Duck',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/2/2b/American_black_duck_male_common.png',
    },
    {
      id: 'an3',
      name: 'Arctic Fox',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/b/bb/Arctic_fox_male_common.png',
    },
    {
      id: 'an4',
      name: 'Axis Deer',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/e/ed/Axis_deer_male_common.png',
    },
    {
      id: 'an5',
      name: 'Banteng',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/b/b1/Banteng_male_common.png',
    },
    {
      id: 'an6',
      name: 'Bighorn Sheep',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/d/de/Bighorn_sheep_male_common.png',
    },
    {
      id: 'an7',
      name: 'Bison',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/c/cd/Bison_male_common.png',
    },
    {
      id: 'an8',
      name: 'Black Bear',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/1/10/Black_bear_male_common.png',
    },
    {
      id: 'an9',
      name: 'Blacktail Deer',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/0/08/Blacktail_deer_male_common.png',
    },
    {
      id: 'an10',
      name: 'Bobcat',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/f/fb/Bobcat_male_common.png',
    },
    {
      id: 'an11',
      name: 'Brown Bear',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/2/2d/Brown_bear_male_common.png',
    },
    {
      id: 'an12',
      name: 'Canada Goose',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/a/a0/Canada_goose_male_common.png',
    },
    {
      id: 'an13',
      name: 'Cottontail Rabbit',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/1/13/Cottontail_rabbit_male_common.png',
    },
    {
      id: 'an14',
      name: 'Coyote',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/6/6d/Coyote_male_common.png', 
    },
    {
      id: 'an15',
      name: 'Dall Sheep',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/b/ba/Dall_sheep_male_common.png', 
    },
    {
      id: 'an16',
      name: 'Eurasian Lynx',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/5/52/Eurasian_lynx_male_common.png',
    },
    {
      id: 'an17',
      name: 'European Rabbit',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/9/9b/European_rabbit_male_common.png',
    },
    {
      id: 'an18',
      name: 'Fallow Deer',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/c/cd/Fallow_deer_male_common.png',
    },
    {
      id: 'an19',
      name: 'Feral Goat',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/c/c0/Feral_goat_male_brown.png',
    },
    {
      id: 'an20',
      name: 'Feral Hog',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/7/71/Feral_hog_male_common.png',
    },
    {
      id: 'an21',
      name: 'Gadwall',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/6/64/Gadwall_male_common.png',
    },
    {
      id: 'an22',
      name: 'Grey Wolf',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/3/3a/Grey_wolf_male_common.png',
    },
    {
      id: 'an23',
      name: 'Grizzly Bear',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/4/4f/Grizzly_bear_male_common.png',
    },
    {
      id: 'an24',
      name: 'Magpie Goose',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/9/98/Magpie_goose_male_common.png',
    },
    {
      id: 'an25',
      name: 'Mallard Duck',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/b/bf/Mallard_male_common.png',
    },
    {
      id: 'an26',
      name: 'Moose',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/a/a8/Moose_male_common.png',
    },
    {
      id: 'an27',
      name: 'Mule Deer',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/b/b6/Mule_deer_male_common.png',
    },
    {
      id: 'an28',
      name: 'Northern Pintail',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/8/83/Northern_pintail_male_common.png',
    },
    {
      id: 'an29',
      name: 'Pheasant',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/c/c4/Pheasant_male_common.png',
    },
    {
      id: 'an30',
      name: 'Polar Bear',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/4/4f/Polar_bear_male_common.png',
    },
    {
      id: 'an31',
      name: 'Puma',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/6/67/Puma_male_common.png',
    },
    {
      id: 'an32',
      name: 'Red Deer',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/8/82/Red_deer_male_common.png',
    },
    {
      id: 'an33',
      name: 'Red Fox',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/1/10/Red_fox_male_common.png',
    },
    {
      id: 'an34',
      name: 'Red Kangaroo',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/8/88/Red_kangaroo_male_common.png',
    },
    {
      id: 'an35',
      name: 'Reindeer',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/9/9a/Reindeer_male_common.png',
    },
    {
      id: 'an36',
      name: 'Rock Ptarmigan',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/2/21/Rock_ptarmigan_male_common.png/',
    },
    {
      id: 'an37',
      name: 'Rocky Mountain Elk',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/1/1b/Rocky_mountain_elk_male_common.png',
    },
    {
      id: 'an38',
      name: 'Roe Deer',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/d/dc/Roe_deer_male_common.png/',
    },
    {
      id: 'an39',
      name: 'Roosevelt Elk',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/b/b6/Roosevelt_elk_male_common.png',
    },
    {
      id: 'an40',
      name: 'Rusa Deer',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/c/cc/Rusa_deer_male_common.png',
    },
    {
      id: 'an41',
      name: 'Sambar Deer',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/d/dc/Sambar_deer_male_common.png',
    },
    {
      id: 'an42',
      name: 'Sitka Deer',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/a/a4/Sitka_deer_male_common.png',
    },
    {
      id: 'an43',
      name: 'Snow Goose',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/5/59/Snow_goose_male_common.png',
    },
    {
      id: 'an44',
      name: 'Snowshoe Hare',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/f/f7/Snowshoe_hare_male_common.png',
    },
    {
      id: 'an45',
      name: 'Turkey',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/f/f2/Turkey_male_common.png',
    },
    {
      id: 'an46',
      name: 'Water Buffalo',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/c/c9/Water_buffalo_male_common.png',
    },
    {
      id: 'an47',
      name: 'Whitetail Deer',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/0/0b/Whitetail_deer_male_common.png',
    },
    {
      id: 'an48',
      name: 'White-tailed Ptarmigan',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/a/a8/White-tailed_ptarmigan_male_common.png',
    },
    {
      id: 'an49',
      name: 'Wild Boar',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/a/a3/Wild_boar_male_common.png',
    },
    {
      id: 'an50',
      name: 'Willow Ptarmigan',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/5/58/Willow_ptarmigan_male_common.png',
    },
    {
      id: 'an51',
      name: 'Wood Grouse',
      url: 'https://static.wikia.nocookie.net/thehuntergame/images/9/95/Wood_grouse_male_common.png',
    },
  ])

  return { animals }
})
