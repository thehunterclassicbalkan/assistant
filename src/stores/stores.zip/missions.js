import { ref, computed } from 'vue'
import { defineStore } from 'pinia'

export const useStoreMissions = defineStore('missions', () => {
  const missions = ref([
    {
      id: "m1",
      name: "Alpine Ibex Missions",
      displayName: "Alpine Ibex",
      animalID: "an1",
      filterArray: ["r8"],
      missionPackValue: "10.000gm$",
      imageURL: "https://static.thehunter.com/static/img/statistics/alpine_ibex.png",
      bgURL: "https://i.postimg.cc/PJDBkpt4/d03d6303-7514-4422-9301-8d7f6f86172a.jpg",
      missionsList: [
        {
          missionID: "m1-1",
          name: "Above all Summits, it is Calm",
          earnings: 100,
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Spot an Alpine Ibex"
          ],
        },
        {
          missionID: "m1-2",
          name: "The Former Bear Biologist Who Stares at Goats",
          earnings: 200,
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "ID droppings of an Alpine Ibex"
          ],
        },
        {
          missionID: "m1-3",
          name: "Joy of Life",
          earnings: 300,
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest an Alpine Ibex"
          ],
        },
        {
          missionID: "m1-4",
          name: "Mountain Hooligans",
          earnings: 400,
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest 3 female Alpine Ibex at 100% Harvest Value in the same hunt"
          ],
        },
        {
          missionID: "m1-5",
          name: "The Sound of a Goat in a Room",
          earnings: 600,
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Register an audio clue of an Alpine Ibex"
          ],
        },
        {
          missionID: "m1-6",
          name: "It's Oh So Quiet",
          earnings: 800,
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Register an audio clue of ANY animal except an Alpine Ibex",
            "Harvest an Alpine Ibex in the same hunt to blame it for making the noise"
          ],
        },
        {
          missionID: "m1-7",
          name: "Blame Science",
          earnings: 1000,
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w28"],
              text: "Require 8x57 IS K98k Bolt Action Rifle"
            },
          ],
          goals: [
            "Harvest an Alpine Ibex from a maximum distance of 60 meter (approx. 197 ft.) using a 8x57 IS K98k Bolt Action Rifle",
            "Harvest another Alpine Ibex from a maximum distance of 50 meter (approx. 164 ft.) using a 8x57 IS K98k Bolt Action Rifle",
            "Harvest another Alpine Ibex from a maximum distance of 40 meter (approx. 131 ft.) using a 8x57 IS K98k Bolt Action Rifle",
            "Harvest another Alpine Ibex from a maximum distance of 30 meter (approx. 98 ft.) using a 8x57 IS K98k Bolt Action Rifle",
          ],
        },
        {
          missionID: "m1-8",
          name: "Goats Blood",
          earnings: 1200,
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w51", "w52", "w53", "w54", "w59", "w60"],
              text: "Require to be killed with tracer arrow"
            },
          ],
          goals: [
            "Harvest 4 Alpine Ibex with a tracer arrow",
            "ID a blood trail of an Alpine Ibex",
            "ID another blood trail of an Alpine Ibex",
          ],
        },
        {
          missionID: "m1-9",
          name: "Again With the Bears",
          earnings: 1800,
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w49"],
              text: "Inline muzzleloader",
            }
          ],
          goals: [
            "Harvest 7 Brown Bear in Val-des-Bois using an Inline Muzzleloader in the same hunt",
          ],
        },
        {
          missionID: "m1-10",
          name: "Taking Down the Bearkiller Goat",
          earnings: 3600,
          singleplayer: true,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest the last Bearkiller Alpine Ibex at the Devil's Teapot in Val-des-Bois (X: 3078, Y: -2169)",
          ],
        },
      ],
    },
    {
      id: "m2",
      name: "Arctic Fox Missions",
      displayName: "Arctic Fox",
      animalID: "an3",
      filterArray: ["r10"],
      missionPackValue: "10.000gm$",
      imageURL: "https://static.thehunter.com/static/img/statistics/arctic_fox.png",
      bgURL: "https://i.postimg.cc/SsCrSWMJ/fa6113a6-3064-45df-89c9-a14cfb9c251d.jpg",
      missionsList: [
        {
          missionID: "m2-1",
          name: "Skittish",
          earnings: "100",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Identify 3 sets of tracks of an Arctic Fox",
            "Identify the droppings of an Arctic Fox"
          ],
        },
        {
          missionID: "m2-2",
          name: "Seeing is Believing",
          earnings: "200",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Identify the call of an Arctic Fox",
            "Spot an Arctic Fox in the same hunt",
            "Harvest an Arctic Fox in the same hunt"
          ],
        },
        {
          missionID: "m2-3",
          name: "Winter Pairs",
          earnings: "300",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Spot and harvest a female Arctic Fox in the same hunt",
            "Spot and harvest a male Arctic Fox in the same hunt",
          ],
        },
        {
          missionID: "m2-4",
          name: "North vs South",
          earnings: "400",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest an Arctic Fox east of Kosatka Harbor",
            "Harvest an Arctic Fox northeast of Tatanka Hot Springs"
          ],
        },
        {
          missionID: "m2-5",
          name: "Oblivious Bang",
          earnings: "600",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest 3 Arctic Foxes at a distance of more than 100 meters (approx. 329 ft.) using a .243 Bolt Action Rifle"
          ],
        },
        {
          missionID: "m2-6",
          name: "Close Up Shot",
          earnings: "800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest 2 Male Arctic Foxes from a maximum distance of 30 meter (approx. 98.5 ft.)"
          ],
        },
        {
          missionID: "m2-7",
          name: "2 for 1",
          earnings: "1000",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest 5 Arctic Foxes using buckshot in the same hunt"
          ],
        },
        {
          missionID: "m2-8",
          name: "The Big Dog",
          earnings: "1200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest 3 male Arctic Foxes weighing at least 6kg (approx. 13.3 lbs.)"
          ],
        },
        {
          missionID: "m2-9",
          name: "Shivers",
          earnings: "1800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              equipments: ["eq2"],
              text: "Tripodstand is required"
            },
          ],
          goals: [
            "Harvest an Arctic Fox using any permitted weapon but without a scope from at least 40 meter (approx. 132 ft.) using a Tripod Stand",
            "Harvest an Arctic Fox using any permitted weapon but without a scope from at least 60 meter (approx. 197 ft.) using a Tripod Stand",
            "Harvest an Arctic Fox using any permitted weapon but without a scope from at least 80 meter (approx. 263 ft.) using a Tripod Stand",
          ],
        },
        {
          missionID: "m2-10",
          name: "Flush",
          earnings: "3600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require:[
            {
              weapons: ["w51", "w52", "w53", "w54", "w55", "w56", "w57", "w58"],
              text: "Require any bow",
            },
            {
              weapons: ["w59", "w60", "w61"],
              text: "Crosbow pistol or any crossbow"
            },
            {
              weapons: ["w42"],
              text: "357 revolver"
            }
          ],
          goals: [
            "Harvest an Arctic Fox with any bow",
            "Harvest an Arctic Fox with any crossbow",
            "Harvest an Arctic Fox with buckshot",
            "Harvest an Arctic Fox with any .243 or .223 rifle",
            "Harvest an Arctic Fox with any permitted revolver",
          ],
        },
      ],
    },
    {
      id: "m3",
      name: "Axis Deer Missions",
      displayName: "Axis Deer",
      animalID: "an4",
      filterArray: ["r9"],
      missionPackValue: "10.000gm$",
      imageURL: "https://static.thehunter.com/static/img/statistics/axis_deer.png",
      bgURL: "https://i.postimg.cc/D0mwQcPz/1f1b5a95-dc47-4c46-a519-adf8f610b606.jpg",
      missionsList: [
        {
          missionID: "m3-1",
          name: "Source the Herd",
          earnings: "100",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "ID 3 clues from different Deer (footprints, audio or droppings)",
          ],
        },
        {
          missionID: "m3-2",
          name: "Necropsy",
          earnings: "200",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "ID droppings from an Axis Deer",
            "Spot an Axis Deer",
            "Harvest an Axis Deer"
          ],
        },
        {
          missionID: "m3-3",
          name: "Matching Pair",
          earnings: "300",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a female Axis Deer",
            "Harvest a male Axis Deer",
          ],
        },
        {
          missionID: "m3-4",
          name: "Prime Sample",
          earnings: "400",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a male Axis Deer scoring more than 130",
          ],
        },
        {
          missionID: "m3-5",
          name: "Trophy Integrity",
          earnings: "600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest an Axis Deer with a single shot using any .270 or .243 rifle"
          ],
        },
        {
          missionID: "m3-6",
          name: "The Shotgun Experiment",
          earnings: "800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a female Axis Deer with buckshot",
            "Harvest a male Axis Deer with a slug"
          ],
        },
        {
          missionID: "m3-7",
          name: "Common Ground",
          earnings: "1000",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Dark male Axis Deer",
            "Harvest an Orange female Axis Deer"
          ],
        },
        {
          missionID: "m3-8",
          name: "Skittish",
          earnings: "1200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w51", "w52", "w53", "w54", "w55", "w56", "w57", "w58"],
              text: "Require any bow",
            },
          ],
          goals: [
            "Harvest an unspooked Axis Deer with any bow (no crossbows) from less than 25m (approx. 82 ft.)",
            "Harvest an Axis Deer with any bow (no crossbows) from more than 25m (approx. 82 ft.)"
          ],
        },
        {
          missionID: "m3-9",
          name: "Taking Matters in Hand",
          earnings: "1800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w47"],
              text: "Require 10mm",
            },
            {
              weapons: ["w42", "w43", "w46"],
              text: "Require any bow",
            },
          ],
          goals: [
            "Harvest an Axis Deer with 10mm ammo from less than 30m. (approx. 98 ft.)",
            "Harvest an Axis Deer with a scoped handgun from more than 40m (approx. 131ft.)",
          ],
        },
        {
          missionID: "m3-10",
          name: "The Beast of Bushranger Run",
          earnings: "3600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w1", "w2"],
              text: "Bilo 223 ili 270"
            },
            {
              weapons: ["w51", "w52", "w53", "w54"],
              text: "Bilo koji compund bow"
            }
          ],
          goals: [
            "Harvest a male Axis Deer weighing more than 95 kg (approx. 209 lbs.) with a shot to the heart or lungs. Other organs may be hit",
          ],
        },
      ],
    },
    {
      id: "m4",
      name: "Banteg Missions",
      displayName: "Banteng",
      animalID: "an5",
      filterArray: ["r12"], // Reservati na kojim se nalazi
      missionPackValue: "10.000gm$",
      imageURL: "https://static.thehunter.com/static/img/statistics/banteng.png",
      bgURL: "https://i.postimg.cc/BQQxkWM8/bc9b968c-1453-40ca-ae01-1cd5d929f8f7.jpg",
      missionsList: [
        {
          missionID: "m4-1",
          name: "Source of the Problem",
          earnings: 100,
          singleplayer: false,
          sameHunt: false,
          selected: false, // da li je zavrsena misija
          passable: true,
          require: [],
          goals: [
            "Spot a Banteng"
          ],
        },
        {
          missionID: "m4-2",
          name: "Retribution Will Follow",
          earnings: "200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Banteng"
          ],
        },
        {
          missionID: "m4-3",
          name: "Tipping the Scales",
          earnings: "300",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Banteng with a weight of at least 600 kg (approx. 1323 lbs)",
            "Harvest another Banteng but with a weight of at least 700 kg (approx. 1543 lbs)",
          ],
        },
        {
          missionID: "m4-4",
          name: "Rumors",
          earnings: "400",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Visit Saint Pauli's Lighthouse (X: 7.553, Y: 8.725) in Piccabeen Bay",
            "Then, harvest an unspooked Banteng with a score of 135 or higher in the same hunt"
          ],
        },
        {
          missionID: "m4-5",
          name: "Revenge Will be Swift",
          earnings: "600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest two Banteng within 10 minutes of each harvest"
          ],
        },
        {
          missionID: "m4-6",
          name: "Restoring Peace and Order",
          earnings: "800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w51", "w52", "w53", "w54"],
              text: "Require any compound bow"
            },
          ],
          goals: [
            "Harvest a Banteng with 100% Harvest Value using any Compound Bow",
            "Harvest another Banteng with 100% Harvest Value using any Compound Bow",
            "Lastly, harvest another Banteng with 100% Harvest Value from a distance of 30 meters (Approx. 98 feet) or further using any Compound Bow"
          ],
        },
        {
          missionID: "m4-7",
          name: "High on Caffeine",
          earnings: "1000",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Then, harvest another Banteng from a distance of 70 meters (Approx. 230 feet) or further with one shot",
          ],
        },
        {
          missionID: "m4-8",
          name: "The High Ground and Low Ground",
          earnings: "1200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              equipments: ["eq2", "eq3"],
              text: "Require to be killed from a Tree Stand or Tripod Stand"
            },
            {
              equipments: ["eq1"],
              text: "Require to be killed from a Ground Blind"
            },
          ],
          goals: [
            "Harvest an unspooked Banteng from a Tree Stand or Tripod Stand",
            "Harvest an unspooked Banteng from a Ground Blind",
          ],
        },
        {
          missionID: "m4-9",
          name: "Hired Mercenaries",
          earnings: "1800",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "First, harvest a charging Water Buffalo from any distance under 15 meters (Approx. 49 feet)",
            "Then, harvest another charging Water Buffalo from any distance under 15 meters (Approx. 49 feet) in the same hunt",
          ],
        },
        {
          missionID: "m4-10",
          name: "Boss Banteng",
          earnings: "3600",
          singleplayer: true,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest the male Boss Banteng by the easternmost island in the swamps of Piccabeen Bay (X: 7.539, Y: 8.299) with one shot",
          ],
        },
      ],
    },
    {
      id: "m5",
      name: "Bighorn Sheep Missions",
      displayName: "Bighorn Sheep",
      animalID: "an6",
      filterArray: ["r11"], // Reservati na kojim se nalazi
      missionPackValue: "10.000gm$",
      imageURL: "https://static.thehunter.com/static/img/statistics/bighorn_sheep.png",
      bgURL: "https://i.postimg.cc/6pvRbSnN/v5B8MaFi.jpg",
      missionsList: [
        {
          missionID: "m5-1",
          name: "Scoping the Sickness",
          earnings: "100",
          singleplayer: false,
          sameHunt: false,
          selected: false, // da li je zavrsena misija
          passable: true,
          require: [],
          goals: [
            "Spot a Bighorn Sheep"
          ],
        },
        {
          missionID: "m5-2",
          name: "Foraging for Feces",
          earnings: "200",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "ID droppings from a Bighorn Sheep",
            "ID droppings from another Bighorn Sheep in the same hunt",
            "ID droppings from another Bighorn Sheep in the same hunt"
          ],
        },
        {
          missionID: "m5-3",
          name: "Confirm the Diagnosis",
          earnings: "300",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Bighorn Sheep",
          ],
        },
        {
          missionID: "m5-4",
          name: "Running Rampant",
          earnings: "400",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w51", "w52", "w53", "w54", "w55", "w56", "w57", "w58", "w59", "w60"],
              text: "Require any bow or crossbow",
            },
          ],
          goals: [
            "Harvest a Bighorn Sheep with a lung shot using a bow or crossbow from under 30 meters (approx. 98 ft)",
            "Harvest another Bighorn Sheep with a lung shot using a bow or crossbow from under 30 meters (approx. 98 ft)"
          ],
        },
        {
          missionID: "m5-5",
          name: "Ewes in Trouble",
          earnings: "600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a female Bighorn Sheep scoring over 40 points",
            "Harvest one more female Bighorn Sheep scoring over 40 points"
          ],
        },
        {
          missionID: "m5-6",
          name: "Grabbing the Disease by the Horns",
          earnings: "800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w51", "w52", "w53", "w54", "w55", "w56", "w57", "w58", "w59", "w60"],
              text: "Require any bow or crossbow",
            },
          ],
          goals: [
            "Harvest a male Bighorn Sheep using a bow or crossbow with 100% Harvest Value",
            "Harvest another male Bighorn Sheep using a bow or crossbow with 100% Harvest Value",
            "Harvest another male Bighorn Sheep using a bow or crossbow with 100% Harvest Value"
          ],
        },
        {
          missionID: "m5-7",
          name: "Out of Her Misery",
          earnings: "1000",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a female Bighorn Sheep weighing under 25kg (approx. 55 lbs) with a shot over 80 meters",
          ],
        },
        {
          missionID: "m5-8",
          name: "The Ram Stops Here",
          earnings: "1200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w13", "w22"],
              text: "Use 7mm Magnum Break Action Rifle or 7mm Magnum Bullpup Rifle"
            },
          ],
          goals: [
            "Harvest a male Bighorn Sheep scoring over 150 points using 7mm Magnum ammunition"
          ],
        },
        {
          missionID: "m5-9",
          name: "Tying up Loose Ewes",
          earnings: "1800",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Bighorn Sheep with a shot through the heart. Other organs may be hit",
            "Harvest another Bighorn Sheep with a shot through the heart. Other organs may be hit",
          ],
        },
        {
          missionID: "m5-10",
          name: "Culling for the Cure",
          earnings: "3600",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Bighorn Sheep",
            "Harvest another Bighorn Sheep in the same hunt",
            "Harvest another Bighorn Sheep in the same hunt"
          ],
        },
      ],
    },
    {
      id: "m6",
      name: "Bison Missions",
      displayName: "Bison",
      animalID: "an7",
      filterArray: ["r10"], // Reservati na kojim se nalazi
      missionPackValue: "10.000gm$",
      imageURL: "https://static.thehunter.com/static/img/statistics/bison.png",
      bgURL: "https://i.postimg.cc/SsCrSWMJ/fa6113a6-3064-45df-89c9-a14cfb9c251d.jpg",
      missionsList: [
        {
          missionID: "m6-1",
          name: "Off On the Wrong Foot",
          earnings: "100",
          singleplayer: false,
          sameHunt: false,
          selected: false, // da li je zavrsena misija
          passable: true,
          require: [],
          goals: [
            "Spot a Bison"
          ],
        },
        {
          missionID: "m6-2",
          name: "A History Lesson",
          earnings: "200",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "ID the tracks of a Bison",
            "ID the tracks of a Bison",
            "ID the tracks of a Bison"
          ],
        },
        {
          missionID: "m6-3",
          name: "The Man Who Saved the Buffalo",
          earnings: "300",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "ID the droppings of a male Bison",
            "ID the droppings of a female Bison",
          ],
        },
        {
          missionID: "m6-4",
          name: "Genetic Issues",
          earnings: "400",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Bison"
          ],
        },
        {
          missionID: "m6-5",
          name: "Bad Blood",
          earnings: "600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a female Bison at 100% Harvest Value"
          ],
        },
        {
          missionID: "m6-6",
          name: "History Repeats Itself",
          earnings: "800",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w49"],
              text: "Require .50 Inline Muzzleloader",
            },
          ],
          goals: [
            "Harvest a male Bison using the inline muzzleloader loaded with a .50 Conical Bullet",
            "Harvest another male Bison using the inline muzzleloader loaded with a .50 Conical Bullet in the same hunt",
            "Harvest another male Bison using the inline muzzleloader loaded with a .50 Conical Bullet in the same hunt"
          ],
        },
        {
          missionID: "m6-7",
          name: "Plague-ridden",
          earnings: "1000",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [
            {
              weapons: [],
              text: "Use .45-70 Government Lever Action Rifle"
            }
          ],
          goals: [
            "Identify a call from a female Bison",
            "Spot a female Bison in the same hunt",
            "Harvest a female Bison weighing at least 450kg (approx. 992 lbs.) in the same hunt using any .45-70 Government Lever Action Rifle"
          ],
        },
        {
          missionID: "m6-8",
          name: "Dirty History",
          earnings: "1200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w55", "w56"],
              text: "Use recurve bow or heavy recurve bow"
            },
          ],
          goals: [
            "Harvest a Bison using any Recurve Bow"
          ],
        },
        {
          missionID: "m6-9",
          name: "Viva la Revolution",
          earnings: "1800",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a male Bison scoring at least 110",
            "Harvest another male Bison scoring at least 110",
          ],
        },
        {
          missionID: "m6-10",
          name: "Challenging Buffalo Bill",
          earnings: "3600",
          singleplayer: true,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w45"],
              text: "Use .454 revolver"
            }
          ],
          goals: [
            "Harvest the male Bison 'Buffalo Bill' last seen at the 'Windy Hill' (X: -6464, Y: -10096) using any permitted revolver without a scope",
          ],
        },
      ],
    },
    {
      id: "m7",
      name: "Black Bear Missions",
      displayName: "Black Bear",
      animalID: "an8",
      filterArray: ["r3", "r4", "r7"], // Reservati na kojim se nalazi
      missionPackValue: "10.000gm$",
      imageURL: "https://static.thehunter.com/static/img/statistics/black_bear.png",
      bgURL: "https://i.postimg.cc/7ZZx892Y/1962ea2d-0595-4b0e-bd3f-5396ce20c84d.jpg",
      missionsList: [
        {
          missionID: "m7-1",
          name: "What We Do For Science",
          earnings: "100",
          singleplayer: false,
          sameHunt: true,
          selected: false, // da li je zavrsena misija
          passable: true,
          require: [],
          goals: [
            "ID a droppings track from a Black Bear in Redfeather Falls",
            "ID a droppings track from another Black Bear in Redfeather Falls in the same hunt",
            "ID a droppings track from another Black Bear in Redfeather Falls in the same hunt"
          ],
        },
        {
          missionID: "m7-2",
          name: "Mercy Cull",
          earnings: "200",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest the infected male Black Bear in Redfeather Falls",
          ],
        },
        {
          missionID: "m7-3",
          name: "Coat of Many Colors",
          earnings: "300",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Spot a Common colored Black Bear in Redfeather Falls",
            "Spot a Common colored Black Bear in Redfeather Falls",
            "Spot a Chocolate colored Black Bear in Redfeather Falls",
            "Spot a Chocolate colored Black Bear in Redfeather Falls",
            "Spot a Blonde colored Black Bear in Redfeather Falls",
            "Spot a Cinnamon colored Black Bear in Redfeather Falls",
            "Spot a Glacier colored Black Bear in Redfeather Falls"
          ],
        },
        {
          missionID: "m7-4",
          name: "Swamp Thing",
          earnings: "400",
          singleplayer: true,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Black Bear on the mysterious island (x: -13582, y: -3293) west of the swamp in Redfeather Falls"
          ],
        },
        {
          missionID: "m7-5",
          name: "Bear Hug",
          earnings: "600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Black Bear in Redfeather Falls weighing less than 100kg (approx. 220lbs.) from less than 30m (approx. 99ft.)"
          ],
        },
        {
          missionID: "m7-6",
          name: "Aftershock",
          earnings: "800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w8"],
              text: "Require .300 Bolt Action Rifle",
            },
          ],
          goals: [
            "Harvest a Black Bears in Redfeather Falls scoring at least 18 using a .300 Rifle",
            "Harvest a Black Bear in Redfeather Falls scoring at least 18 using a .300 Rifle",
            "Harvest a Black Bear in Redfeather Falls scoring at least 18 using a .300 Rifle"
          ],
        },
        {
          missionID: "m7-7",
          name: "Lead N Fur",
          earnings: "1000",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Black Bear scoring at least 20 using a slug from more than 50m (approx. 164ft.) in Redfeather Falls",
          ],
        },
        {
          missionID: "m7-8",
          name: "Bloodlust",
          earnings: "1200",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Black Bear in Redfeather Falls in same hunt",
            "Harvest a Black Bear in Redfeather Falls in same hunt",
            "Harvest a Black Bear in Redfeather Falls in same hunt",
            "Harvest a Black Bear in Redfeather Falls in same hunt"
          ],
        },
        {
          missionID: "m7-9",
          name: "Getting Closer",
          earnings: "1800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w51"],
              text: 'Use Compound bow Snakebite'
            }
          ],
          goals: [
            "Harvest a male Black Bear in Redfeather Falls weighing more than 200kg (approx. 441lbs.) using the Snakebite Compound Bow",
          ],
        },
        {
          missionID: "m7-10",
          name: "Illegally Blonde",
          earnings: "3600",
          singleplayer: true,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest the angry blonde Black Bear in the northwest corner (x: -12614, y: -6282) of Redfeather Falls. Keep in mind that the bear will be roaming approx. a 150m (492 ft) radius around the area",
          ],
        },
      ],
    },
    {
      id: "m8",
      name: "Blacktail Deer Missions",
      displayName: "Blacktail Deer",
      animalID: "an9",
      filterArray: ["r1", "r4"], // Reservati na kojim se nalazi
      missionPackValue: "10.000gm$",
      imageURL: "https://static.thehunter.com/static/img/statistics/blacktail_deer.png",
      bgURL: "https://i.postimg.cc/7ZZx892Y/1962ea2d-0595-4b0e-bd3f-5396ce20c84d.jpg",
      missionsList: [
        {
          missionID: "m8-1",
          name: "Breaking Ice",
          earnings: "100",
          singleplayer: false,
          sameHunt: false,
          selected: false, // da li je zavrsena misija
          passable: true,
          require: [],
          goals: [
            "Harvest a Blacktail Deer"
          ],
        },
        {
          missionID: "m8-2",
          name: "Dying To Impress",
          earnings: "200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w34"],
              text: "Use 12 GA Pump Action Shotgun"
            }
          ],
          goals: [
            "Harvest a Male Blacktail Deer with the Pump-Action Shotgun",
          ],
        },
        {
          missionID: "m8-3",
          name: "By The Book",
          earnings: "300",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "ID 3 tracks from a Blacktail Deer",
            "Spot a Blacktail Deer in same hunt",
            "Harvest a Blacktail Deer in same hunt",
          ],
        },
        {
          missionID: "m8-4",
          name: "A Long Distance Relation",
          earnings: "400",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w9"],
              text: "Use .308 Anschütz 1780 D FL Bolt Action Rifle"
            }
          ],
          goals: [
            "Harvest a Male Blacktail Deer from more than 150m using the .308 Anschütz Rifle"
          ],
        },
        {
          missionID: "m8-5",
          name: "Anywhere But Here",
          earnings: "600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Blacktail Deer scoring at least 120 from a distance of less than 30 m"
          ],
        },
        {
          missionID: "m8-6",
          name: "Making Nice",
          earnings: "800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w48"],
              text: "Use .50 Cap Lock Muzzleloader",
            },
          ],
          goals: [
            "Harvest a Male Blacktail Deer With at least 10 typical points using the .50 Cap Lock Muzzleloader"
          ],
        },
        {
          missionID: "m8-7",
          name: "Getting Serious",
          earnings: "1000",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Blacktail Deer from Tower 8 on Whitehart Island",
            "Harvest a Blacktail Deer from Tower 6 on Whitehart Island during the same hunt",
          ],
        },
        {
          missionID: "m8-8",
          name: "Moving In",
          earnings: "1200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              equipments: ["eq3"],
              text: 'You must use Treestand'
            }
          ],
          goals: [
            "Harvest a Male Blacktail Deer from a Treestand",
            "Harvest a Male Blacktail Deer from a Treestand",
            "Harvest a Male Blacktail Deer from a Treestand"
          ],
        },
        {
          missionID: "m8-9",
          name: "12 Counts of Affection",
          earnings: "1800",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest 12 Blacktail Deers in the same hunt",
          ],
        },
        {
          missionID: "m8-10",
          name: "Tying Up",
          earnings: "3600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w55", "w56"],
              text: "You need to use Heavy recurve or recurve bow"
            }
          ],
          goals: [
            "Harvest a Male Blacktail Deer scoring more than 135 with any Recurve Bow",
          ],
        },
      ],
    },
    {
      id: "m9",
      name: "Bobcat Missions",
      displayName: "Bobcat",
      animalID: "an10",
      filterArray: ["r1", "r2", "r3", "r7"], // Reservati na kojim se nalazi
      missionPackValue: "10.000gm$",
      imageURL: "https://static.thehunter.com/static/img/statistics/bobcat.png",
      bgURL: "https://i.postimg.cc/7ZZx892Y/1962ea2d-0595-4b0e-bd3f-5396ce20c84d.jpg",
      missionsList: [
        {
          missionID: "m9-1",
          name: "Every Mewment Counts",
          earnings: "100",
          singleplayer: false,
          sameHunt: false,
          selected: false, // da li je zavrsena misija
          passable: true,
          require: [],
          goals: [
            "ID Bobcat tracks or droppings in Whitehart Island",
            "Spot a Bobcat in Whitehart Island"
          ],
        },
        {
          missionID: "m9-2",
          name: "Can Somebody Paw-lease Give This Man a Bobcat?",
          earnings: "200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Bobcat in Whitehart Island",
          ],
        },
        {
          missionID: "m9-3",
          name: "Meow-sicians in Logger's Point",
          earnings: "300",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Visit the Inland Campsite in Logger's Point",
            "Visit the Campsite in Logger's Point",
            "At any time, ID a call from a Bobcat in Logger's Point",
          ],
        },
        {
          missionID: "m9-4",
          name: "Find All the Purrpetrators",
          earnings: "400",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Bobcat using any buckshot in Logger's Point",
            "Harvest another Bobcat using any buckshot in Logger's Point"
          ],
        },
        {
          missionID: "m9-5",
          name: "In Pursuit of Purrfection",
          earnings: "600",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest an unspooked male Bobcat without using any type of buckshot at 100% Harvest Value in Logger's Point in the same hunt",
            "Harvest an unspooked female Bobcat without using any type of buckshot at 100% Harvest Value in Logger's Point in the same hunt"
          ],
        },
        {
          missionID: "m9-6",
          name: "Cathletic Cats by the Creeks",
          earnings: "800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              equipments: ["eq3"],
              text: "You must use Tree Stand",
            },
          ],
          goals: [
            "Locate 3 Bobcat tracks from the same animal in Settler Creeks",
            "Harvest a Bobcat in Settler Creeks while using a Tree Stand with a single shot"
          ],
        },
        {
          missionID: "m9-7",
          name: "Everything Looking Paw-sitive",
          earnings: "1000",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [
            {
              equipments: ["eq3"],
              text: "You must use Tree Stand",
            },
          ],
          goals: [
            "Harvest a Bobcat with a score of 7 or higher while using a Tree Stand in Settler Creeks",
            "Harvest a Bobcat with a weight of 16 kg (Approx. 32 lbs) or lower while using a Tree Stand in Settler Creeks",
          ],
        },
        {
          missionID: "m9-8",
          name: "Endless Paw-sibilities",
          earnings: "1200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Head over to Riverhead Landing in Rougarou Bayou",
            "Once at Riverhead Landing, harvest an unspooked Bobcat with a score of 8 or lower in Rougarou Bayou",
            "Once at Riverhead Landing, harvest an unspooked Bobcat with a score of 8 or higher in Rougarou Bayou"
          ],
        },
        {
          missionID: "m9-9",
          name: "Run, Bobcat, Run!",
          earnings: "1800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a male Bobcat with a score of 8 or higher at 100% Harvest Value while it's fleeing",
          ],
        },
        {
          missionID: "m9-10",
          name: "The El Bobogato Ceremony",
          earnings: "3600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest two Bobcats within 5 minutes of each harvest",
          ],
        },
      ],
    },
    {
      id: "m10",
      name: "Brown Bear Missions",
      displayName: "Brown Bear",
      animalID: "an11",
      filterArray: ["r6", "r8"], // Reservati na kojim se nalazi
      missionPackValue: "10.000gm$",
      imageURL: "https://static.thehunter.com/static/img/statistics/brown_bear.png",
      bgURL: "https://i.postimg.cc/1RCNdqkM/output.jpg",
      missionsList: [
        {
          missionID: "m10-1",
          name: "The Comeback Kid",
          earnings: "100",
          singleplayer: false,
          sameHunt: true,
          selected: false, // da li je zavrsena misija
          passable: true,
          require: [],
          goals: [
            "ID tracks from a Brown Bear",
            "ID tracks from another Brown Bear in the same outing",
            "ID tracks from another Brown Bear in the same outing"
          ],
        },
        {
          missionID: "m10-2",
          name: "Head Count",
          earnings: "200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Spot a Brown Bear",
            "Spot a Brown Bear",
            "Spot a Brown Bear"
          ],
        },
        {
          missionID: "m10-3",
          name: "Southpaw",
          earnings: "300",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Brown Bear"
          ],
        },
        {
          missionID: "m10-4",
          name: "Heavy Hitter",
          earnings: "400",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Brown Bear weighing at least 300 kg (approx. 661 lbs)"
          ],
        },
        {
          missionID: "m10-5",
          name: "Slugger",
          earnings: "600",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w34"],
              text: "You must use 12 GA Pump Action Shotgun"
            }
          ],
          goals: [
            "Harvest a Brown Bear using a 12 GA Pump Action Shotgun loaded with slugs",
            "Harvest a Brown Bear using a 12 GA Pump Action Shotgun loaded with slugs during the same hunt"
          ],
        },
        {
          missionID: "m10-6",
          name: "Bad News Bears",
          earnings: "800",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Brown Bear",
            "Harvest another Brown Bear in the same hunt",
            "Harvest another Brown Bear in the same hunt"
          ],
        },
        {
          missionID: "m10-7",
          name: "Far-fetched",
          earnings: "1000",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w16"],
              text: "You must use 9.3x62 Anschütz 1780 D FL Bolt Action Rifle with a scope",
            },
          ],
          goals: [
            "Harvest a Brown Bear using a scoped 9.3x62 Anschütz 1780 D FL Bolt Action Rifle at a minimum distance of 100 meters (approx. 328 ft)"
          ],
        },
        {
          missionID: "m10-8",
          name: "Biologist Schmiologist",
          earnings: "1200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              equipments: ["eq1"],
              text: "You must use Ground Blind"
            }
          ],
          goals: [
            "Harvest a Brown Bear from a Ground Blind",
            "Harvest another Brown Bear using a Ground Blind"
          ],
        },
        {
          missionID: "m10-9",
          name: "This All Sounds Awfully Familiar",
          earnings: "1800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w52"],
              text: "Use Parker Python Compound Bow"
            }
          ],
          goals: [
            "Harvest a Brown Bear using a Parker Python Compound Bow from a maximum of 20 meters (approx 66 ft)",
          ],
        },
        {
          missionID: "m10-10",
          name: "We Woke Up The Mama",
          earnings: "3600",
          singleplayer: true,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w46"],
              text: 'Use .308 Handgun'
            }
          ],
          goals: [
            "Harvest the Brown Bear Goldilocks using a .308 'Rival' Handgun",
          ],
        },
      ],
    },
    {
      id: "m11",
      name: "Canada Goose Missions",
      displayName: "Canada Goose",
      animalID: "an12",
      filterArray: ["r5"], // Reservati na kojim se nalazi
      missionPackValue: "10.000gm$",
      imageURL: "https://static.thehunter.com/static/img/statistics/canada_goose.png",
      bgURL: "https://i.postimg.cc/fbWdWb1M/1Q8E8Rr9.jpg",
      missionsList: [
        {
          missionID: "m11-1",
          name: "Allright Then: Prove It",
          earnings: "100",
          singleplayer: false,
          sameHunt: false,
          selected: false, // da li je zavrsena misija
          passable: true,
          require: [],
          goals: [
            "Harvest an airborne Canada Goose",
            "Harvest Moose"
          ],
        },
        {
          missionID: "m11-2",
          name: "Off On The Wrong Foot",
          earnings: "200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "ID the call of a Canada Goose",
            "ID the call of another Canada Goose"
          ],
        },
        {
          missionID: "m11-3",
          name: "The Standard Procedure",
          earnings: "300",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest 5 airborne Canada Geese in the same hunt"
          ],
        },
        {
          missionID: "m11-4",
          name: "Easy Riding",
          earnings: "400",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest 3 airborne Canada Geese using a 12 GA Single Shot Shotgun killing it with one shot in the same hunt"
          ],
        },
        {
          missionID: "m11-5",
          name: "Full Throttle",
          earnings: "600",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w40"],
              text: "You must use 20 GA Semi-Automatic Shotgun"
            }
          ],
          goals: [
            "Harvest 10 airborne Canada Geese using a 20 GA Semi-Automatic Shotgun in the same hunt"
          ],
        },
        {
          missionID: "m11-6",
          name: "Surgeon With A Shotgun",
          earnings: "800",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest 3 airborne Canada Geese from a minimum of 40 meters (approx. 131 ft.) in the same hunt"
          ],
        },
        {
          missionID: "m11-7",
          name: "Antiquated Measurements",
          earnings: "1000",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest an airborne Canada Goose weighing at least 200 Salerno libras (or 7,2 kg, approx. 15,4 lbs.)",
            "Harvest another airborne Canada Goose weighing at least 200 Salerno libras (or 7,2 kg, approx. 15,4 lbs.)"
          ],
        },
        {
          missionID: "m11-8",
          name: "Trickery In The Name Of Justice",
          earnings: "1200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              equipments: ["eq4"],
              text: "You must use Waterfowl Blind"
            }
          ],
          goals: [
            "Harvest 4 airborne Canada Geese from a Waterfowl Blind at a maximum distance of 15 meter (approx. 49 ft.)"
          ],
        },
        {
          missionID: "m11-9",
          name: "A Light At The End Of The Tunnel?",
          earnings: "1800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w41"],
              text: "Use .22 Pistol"
            }
          ],
          goals: [
            "Harvest 2 airborne Canada Geese using a .22 Pistol.",
          ],
        },
        {
          missionID: "m11-10",
          name: "Like In The Olden Days",
          earnings: "3600",
          singleplayer: true,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w57"],
              text: 'Use Longbow'
            }
          ],
          goals: [
            "Harvest an airborne Canada Goose using a Longbow",
          ],
        },
      ],
    },
    {
      id: "m12",
      name: "Cottontail Rabbit Missions",
      displayName: "Cottontail Rabbit",
      animalID: "an13",
      filterArray: ["r2", "r3"], // Reservati na kojim se nalazi
      missionPackValue: "10.000gm$",
      imageURL: "https://static.thehunter.com/static/img/statistics/cottontail_rabbit.png",
      bgURL: "https://i.postimg.cc/7ZZx892Y/1962ea2d-0595-4b0e-bd3f-5396ce20c84d.jpg",
      missionsList: [
        {
          missionID: "m12-1",
          name: "Hop To It",
          earnings: "100",
          singleplayer: false,
          sameHunt: false,
          selected: false, // da li je zavrsena misija
          passable: true,
          require: [],
          goals: [
            "Spot a Cottontail Rabbit in Logger's Point",
            "ID tracks or droppings of a Cottontail Rabbit in Logger's Point",
            "Spot a Cottontail Rabbit in Settler Creeks",
            "ID tracks or droppings of a Cottontail Rabbit in Settler Creeks"
          ],
        },
        {
          missionID: "m12-2",
          name: "Regicide",
          earnings: "200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Cottontail Rabbit"
          ],
        },
        {
          missionID: "m12-3",
          name: "Honour. Glory. Rabbit.",
          earnings: "300",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Cottontail Rabbit using a Shotgun",
            "Harvest another Cottontail Rabbit using a Shotgun"
          ],
        },
        {
          missionID: "m12-4",
          name: "Ode To Joy",
          earnings: "400",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest 4 Cottontail Rabbits in Settler Creeks using a 12 GA Single Shot Shotgun"
          ],
        },
        {
          missionID: "m12-5",
          name: "Warriors Of The Fields",
          earnings: "600",
          singleplayer: true,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Go to the Three Lakes area on Logger's Point and investigate how the war between Cottontail Rabbits and Coyotes is going. Check out some strange reports coming out of somewhere close to these coordinates: X: -9511; Y: 5756"
          ],
        },
        {
          missionID: "m12-6",
          name: "Losers Of The Fields",
          earnings: "800",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [
            {
              equipments: ["eq1"],
              text: "you must use Ground Blind"
            }
          ],
          goals: [
            "Harvest 2 Cottontail Rabbits from a Ground Blind in the same hunt"
          ],
        },
        {
          missionID: "m12-7",
          name: "Restoring The Honour",
          earnings: "1000",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest 2 Cottontail Rabbits while crouching from a maximum distance of 20 meter (approx. 66 ft.)"
          ],
        },
        {
          missionID: "m12-8",
          name: "Restoring The Glory",
          earnings: "1200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w5"],
              text: "You must use .22 Air Rifle"
            }
          ],
          goals: [
            "Harvest 3 Cottontail Rabbits in Settler Creeks using a .22 Air Rifle without a scope"
          ],
        },
        {
          missionID: "m12-9",
          name: "Losers No More",
          earnings: "1800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w57"],
              text: "Use Longbow"
            },
            {
              equipments: ["eq3"],
              text: "Use Treestand"
            }
          ],
          goals: [
            "Harvest 2 unspooked Cottontail Rabbits in Logger's Point from a Treestand using a Longbow",
          ],
        },
        {
          missionID: "m12-10",
          name: "Duty First",
          earnings: "3600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w40"],
              text: 'Use 20 GA Semi-Automatic Shotgun'
            }
          ],
          goals: [
            "Harvest 5 Cottontail Rabbits in Settler Creeks using a 20 GA Semi-Automatic Shotgun",
          ],
        },
      ],
    },
    {
      id: "m13",
      name: "Coyote Missions",
      displayName: "Coyote",
      animalID: "an14",
      filterArray: ["r1", "r2"], // Reservati na kojim se nalazi
      missionPackValue: "9.000gm$",
      imageURL: "https://static.thehunter.com/static/img/statistics/coyote.png",
      bgURL: "https://i.postimg.cc/7ZZx892Y/1962ea2d-0595-4b0e-bd3f-5396ce20c84d.jpg",
      missionsList: [
        {
          missionID: "m13-1",
          name: "Eye Spy",
          earnings: "100",
          singleplayer: false,
          sameHunt: false,
          selected: false, // da li je zavrsena misija
          passable: true,
          require: [],
          goals: [
            "Spot a Coyote"
          ],
        },
        {
          missionID: "m13-2",
          name: "It Takes Two",
          earnings: "200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Coyote",
            "Harvest a Coyote"
          ],
        },
        {
          missionID: "m13-3",
          name: "Scout",
          earnings: "300",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Find a set of Coyote tracks",
            "Find a set of Coyote tracks",
            "Find a set of Coyote tracks"
          ],
        },
        {
          missionID: "m13-4",
          name: "Barking Up The Wrong Tower",
          earnings: "500",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Coyote from a tower"
          ],
        },
        {
          missionID: "m13-5",
          name: "Northern Quarter",
          earnings: "700",
          singleplayer: true,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Coyote from the Northern Quarter"
          ],
        },
        {
          missionID: "m13-6",
          name: "Bitchin'",
          earnings: "900",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w43"],
              text: "You must use .44 Revolver"
            }
          ],
          goals: [
            "Harvest a female Coyote, using a .44 Magnum Revolver",
            "Harvest a female Coyote, using a .44 Magnum Revolver",
            "Harvest a female Coyote, using a .44 Magnum Revolver",
            "Harvest a female Coyote, using a .44 Magnum Revolver",
            "Harvest a female Coyote, using a .44 Magnum Revolver"
          ],
        },
        {
          missionID: "m13-7",
          name: "Lake Coyote?",
          earnings: "1200",
          singleplayer: true,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Coyote from the Lake (X: -14058, Y: 5389)"
          ],
        },
        {
          missionID: "m13-8",
          name: "Bow Wow",
          earnings: "1600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w51"],
              text: "You must use Compound Bow Snakebite"
            }
          ],
          goals: [
            "Harvest a Coyote, using the 'Snakebite' Compound Bow",
            "Harvest a Coyote, using the 'Snakebite' Compound Bow",
            "Harvest a Coyote, using the 'Snakebite' Compound Bow",
            "Harvest a Coyote, using the 'Snakebite' Compound Bow",
            "Harvest a Coyote, using the 'Snakebite' Compound Bow"
          ],
        },
        {
          missionID: "m13-9",
          name: "Take Down",
          earnings: "1800",
          singleplayer: true,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest the Big Dog from the Awi'Usdi Stones",
          ],
        },
      ],
    },
    {
      id: "m14",
      name: "Dall Sheep Missions",
      displayName: "Dall Sheep",
      animalID: "an15",
      filterArray: ["r10"], // Reservati na kojim se nalazi
      missionPackValue: "10.000gm$",
      imageURL: "https://static.thehunter.com/static/img/statistics/dall_sheep.png",
      bgURL: "https://i.postimg.cc/PJDBkpt4/d03d6303-7514-4422-9301-8d7f6f86172a.jpg",
      missionsList: [
        {
          missionID: "m14-1",
          name: "Flocking To The Hills",
          earnings: "100",
          singleplayer: false,
          sameHunt: false,
          selected: false, // da li je zavrsena misija
          passable: true,
          require: [],
          goals: [
            "Locate 3 Dall Sheep tracks from the same animal",
            "Spot a Dall Sheep"
          ],
        },
        {
          missionID: "m14-2",
          name: "Don't Be So Sheepish",
          earnings: "200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Dall Sheep"
          ],
        },
        {
          missionID: "m14-3",
          name: "I Only Have Eyes For Ewe",
          earnings: "300",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a female Dall Sheep",
            "Harvest another female Dall Sheep",
            "Harvest one last female Dall Sheep"
          ],
        },
        {
          missionID: "m14-4",
          name: "If You Can't Dodge It",
          earnings: "400",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a male Dall Sheep with a single shot using any ethical weapon"
          ],
        },
        {
          missionID: "m14-5",
          name: "Hoofin' It",
          earnings: "600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a male Dall Sheep with a shot through the heart or both lungs. Other organs may be hit",
            "Harvest another male Dall Sheep with a shot through the heart or both lungs in the same hunt. Other organs may be hit"
          ],
        },
        {
          missionID: "m14-6",
          name: "No Ewes Crying Over Spilt Milk",
          earnings: "800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a female Dall Sheep using any .243 rifle from over 150 meters (Approx. 492 ft)"
          ],
        },
        {
          missionID: "m14-7",
          name: "Mutton For Punishment",
          earnings: "1000",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a female Dall Sheep weighing over 45kg (Approx. 99 lbs)",
            "Harvest a male Dall Sheep weighing over 90kg (Approx. 198 lbs)"
          ],
        },
        {
          missionID: "m14-8",
          name: "Shear Delights",
          earnings: "1200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest two Dall Sheep within 5 minutes of one another"
          ],
        },
        {
          missionID: "m14-9",
          name: "The Black Sheep",
          earnings: "1800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a male Dall Sheep scoring over 160 points with a 100% Harvest Value",
          ],
        },
        {
          missionID: "m14-10",
          name: "Put To Good Ewes",
          earnings: "3600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a female Dall Sheep scoring less than 35 points",
            "Harvest a female Dall Sheep scoring over 38 points",
            "Harvest a male Dall Sheep scoring less than 80 points",
            "Harvest a male Dall Sheep scoring over 160 points"
          ],
        },
      ],
    },
    {
      id: "m15",
      name: "Eurasian Lynx Missions",
      displayName: "Eurasian Lynx",
      animalID: "an16",
      filterArray: ["r6"], // Reservati na kojim se nalazi
      missionPackValue: "10.000gm$",
      imageURL: "https://static.thehunter.com/static/img/statistics/lynx_eurasian.png",
      bgURL: "https://i.postimg.cc/1RCNdqkM/output.jpg",
      missionsList: [
        {
          missionID: "m15-1",
          name: "The Search for Pakasuchus",
          earnings: "100",
          singleplayer: false,
          sameHunt: false,
          selected: false, // da li je zavrsena misija
          passable: true,
          require: [],
          goals: [
            "ID the call of a Eurasian Lynx",
            "Find a track from a Eurasian Lynx"
          ],
        },
        {
          missionID: "m15-2",
          name: "Modern Fossil Requirement",
          earnings: "200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest an Eurasian Lynx"
          ],
        },
        {
          missionID: "m15-3",
          name: "The Brachiosaurus Lynx",
          earnings: "300",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest an Eurasian Lynx with a weight of 23 kg (Approx. 51 lbs) or higher"
          ],
        },
        {
          missionID: "m15-4",
          name: "The Velocilynx",
          earnings: "400",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w59", "w60", "w61"],
              text: "Use Reverse Draw Crossbow or Tenpoint Carbon Fusion Crossbow or Crossbow Pistol"
            },
          ],
          goals: [
            "Harvest an Eurasian Lynx with a score of 7 or higher with any Crossbow or Crossbow Pistol"
          ],
        },
        {
          missionID: "m15-5",
          name: "The Predator Becomes the Prey",
          earnings: "600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              equipments: ["eq3"],
              text: "You must use Treestand"
            } 
          ],
          goals: [
            "Spot a male Eurasian Lynx from a Treestand",
            "Spot another male Eurasian Lynx from a Treestand",
            "Spot one final male Eurasian Lynx from a Treestand"
          ],
        },
        {
          missionID: "m15-6",
          name: "Upgrading Equipment",
          earnings: "800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest two Eurasian Lynx within 10 minutes of each harvest"
          ],
        },
        {
          missionID: "m15-7",
          name: "The Argentinosaurus Lynx",
          earnings: "1000",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest an unspooked Eurasian Lynx with a weight of 30 kg (Approx. 66 lbs) or higher at a distance under 20 meters (Approx. 65 feet)"
          ],
        },
        {
          missionID: "m15-8",
          name: "The T-Lynx",
          earnings: "1200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest an unspooked Eurasian Lynx with a score of 9 or higher with any Shotgun using any buckshot at 100% Harvest Value"
          ],
        },
        {
          missionID: "m15-9",
          name: "Pakasuchus",
          earnings: "1800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              equipments: ["eq3"],
              text: "You must use Treestand"
            }
          ],
          goals: [
            "Harvest an unspooked male Eurasian Lynx from a Tree Stand while it's standing still",
          ],
        },
        {
          missionID: "m15-10",
          name: "A Distant Relative",
          earnings: "3600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest an unspooked male Eurasian Lynx at 100% Harvest Value with a score of 9 or higher without penetrating any bones. Only organs may be hit"
          ],
        },
      ],
    },
    {
      id: "m16",
      name: "European Rabbit Missions",
      displayName: "European Rabbit",
      animalID: "an16",
      filterArray: ["r8", "r9"], // Reservati na kojim se nalazi
      missionPackValue: "10.000gm$",
      imageURL: "https://static.thehunter.com/static/img/statistics/european_rabbit.png",
      bgURL: "https://i.postimg.cc/D0mwQcPz/1f1b5a95-dc47-4c46-a519-adf8f610b606.jpg",
      missionsList: [
        {
          missionID: "m16-1",
          name: "Finding the clues",
          earnings: "100",
          singleplayer: false,
          sameHunt: false,
          selected: false, // da li je zavrsena misija
          passable: true,
          require: [],
          goals: [
            "ID tracks from a European Rabbit",
            "ID more tracks from a European Rabbit",
            "ID droppings from a European Rabbit"
          ],
        },
        {
          missionID: "m16-2",
          name: "Rabbit Therapy",
          earnings: "200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Spot an European Rabbit",
            "Spot a second European Rabbit",
            "Spot a third European Rabbit"
          ],
        },
        {
          missionID: "m16-3",
          name: "Too many, too fast",
          earnings: "300",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a European Rabbit",
            "Harvest another European Rabbit"
          ],
        },
        {
          missionID: "m16-4",
          name: "Non Strategical Rabbits",
          earnings: "400",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [
            {
              equipments: ["eq1"],
              text: "Ground Blind required"
            },
          ],
          goals: [
            "Harvest an European Rabbit killed from a Ground Blind",
            "Harvest another European Rabbit killed from a Ground Blind during the same hunt",
            "Harvest another European Rabbit killed from a Ground Blind during the same hunt"
          ],
        },
        {
          missionID: "m16-5",
          name: "Power In Numbers",
          earnings: "600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w5"],
              text: "You must use .22 Air Rifle"
            } 
          ],
          goals: [
            "Harvest a female European Rabbit weighing less than 1,7 kg killed with a .22 Air Rifle",
            "Harvest a female European Rabbit weighing between 1,7 kg and 2,0 kg killed with a .22 Air Rifle",
            "Harvest a female European Rabbit weighing more than 2,0 kg killed with a .22 Air Rifle"
          ],
        },
        {
          missionID: "m16-6",
          name: "Keeping Them On Their Toes",
          earnings: "800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a male European Rabbit killed while spooked with a 12 GA Single Shot Shotgun",
            "Harvest a female European Rabbit killed while spooked with a 12 GA Single Shot Shotgun"
          ],
        },
        {
          missionID: "m16-7",
          name: "Home Invasion",
          earnings: "1000",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest an European Rabbit killed with any shotgun while it is emerging from or diving into a burrow exit",
            "Harvest a second European Rabbit killed with any shotgun while it is emerging from or diving into a burrow exit during the same hunt",
            "Harvest a third European Rabbit killed with any shotgun while it is emerging from or diving into a burrow exit during the same hunt"
          ],
        },
        {
          missionID: "m16-8",
          name: "A Necessary Evil",
          earnings: "1200",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [
            {
              equipments: ["eq1"],
              text: "Use Ground blind"
            }
          ],
          goals: [
            "Spot an European Rabbit during the same hunt",
            "Spot another European Rabbit during the same hunt",
            "Harvest a spooked European Rabbit from a Ground Blind during the same hunt",
            "Harvest another spooked European Rabbit from a Ground Blind during the same hunt"
          ],
        },
        {
          missionID: "m16-9",
          name: "Can't Break Their Spirit",
          earnings: "1800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "ID tracks from a European Rabbit",
            "ID a second set tracks from a European Rabbit",
            "ID a third set of tracks from a European Rabbit",
            "Spot a European Rabbit",
            "Spot a second European Rabbit",
            "Spot a third European Rabbit"
          ],
        },
        {
          missionID: "m16-10",
          name: "Rabbit Rampage",
          earnings: "3600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ['w41'],
              text: ".22 Pistol"
            }
          ],
          goals: [
            "Harvest a female European Rabbit north of Chalet du Mont-Bleu lodge",
            "Harvest a second female European Rabbit north of Chalet du Mont-Bleu lodge",
            "Harvest a female European Rabbit northwest of The Calm Pond (x 2559, y -848)",
            "Harvest a second female European Rabbit killed with the .22 Pistol north of The Calm Pond (x 2559, y -848)",
            "Harvest a male European Rabbit north of Chalet du Mont-Bleu lodge",
            "Harvest a second male European Rabbit killed with the .22 Pistol north of Chalet du Mont-Bleu lodge",
            "Harvest a male European Rabbit north of The Calm Pond (x 2559, y -848)",
            "Harvest a second male European Rabbit north of The Calm Pond (x 2559, y -848)"
          ],
        },
      ],
    },
    {
      id: "m17",
      name: "Fallow Deer Missions",
      displayName: "Fallow Deer",
      animalID: "an18",
      filterArray: ["r5"], // Reservati na kojim se nalazi
      missionPackValue: "10.000gm$",
      imageURL: "https://static.thehunter.com/static/img/statistics/fallow_deer.png",
      bgURL: "https://i.postimg.cc/fbWdWb1M/1Q8E8Rr9.jpg",
      missionsList: [
        {
          missionID: "m17-1",
          name: "Clued In",
          earnings: "100",
          singleplayer: false,
          sameHunt: true,
          selected: false, // da li je zavrsena misija
          passable: true,
          require: [],
          goals: [
            "ID footprints from a Fallow Deer",
            "ID droppings from a Fallow Deer in the same hunt",
            "ID ID an audio call from a Fallow Deer in the same hunt"
          ],
        },
        {
          missionID: "m17-2",
          name: "Eyes on the Target",
          earnings: "200",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Spot a Fallow Deer",
            "Spot another Fallow Deer in the same hunt",
            "Spot a third Fallow Deer in the same hunt"
          ],
        },
        {
          missionID: "m17-3",
          name: "Sampling the Herd",
          earnings: "300",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a female Fallow Deer",
            "Harvest a male Fallow Deer in the same hunt"
          ],
        },
        {
          missionID: "m17-4",
          name: "Regional Differences",
          earnings: "400",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Fallow Deer from Tower 4 (x 8504, y -25)"
          ],
        },
        {
          missionID: "m17-5",
          name: "Unstressed Meat",
          earnings: "600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest an unspooked Fallow Deer with any buckshot ammunition"
          ],
        },
        {
          missionID: "m17-6",
          name: "To the North",
          earnings: "800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Fallow Deer from Tower 5 (x 8814, y -1145) with a heart or lung shot"
          ],
        },
        {
          missionID: "m17-7",
          name: "A Fine Pair",
          earnings: "1000",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w42", "w43", "w47", "w46"],
              text:"Use .357, .44, 10mm Semi-Automatic Pistol or .308 Handgun"
            }
          ],
          goals: [
            "Harvest a male Fallow Deer with a handgun",
            "Harvest a female Fallow Deer with a handgun"
          ],
        },
        {
          missionID: "m17-8",
          name: "Final Land Survey",
          earnings: "1200",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [
            {
              equipments: ["eq3"],
              text: "Use Tree Stand"
            }
          ],
          goals: [
            "Harvest a male Fallow Deer from a Tree Stand with a single shot",
            "Harvest a female Fallow Deer from a Tree Stand with a single shot in the same hunt"
          ],
        },
        {
          missionID: "m17-9",
          name: "Changing Tactics",
          earnings: "1800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w51", "w52", "w53", "w54", "w55", "w56", "w57", "w58", "w59", "w60"],
              text: "Use any bow or crossbow"
            }
          ],
          goals: [
            "Harvest a male Chocolate Fallow Deer scoring more than 135 with any bow or crossbow",
          ],
        },
        {
          missionID: "m17-10",
          name: "Full Utility",
          earnings: "3600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a male Fallow Deer scoring more than 155"
          ],
        },
      ],
    },
    {
      id: "m18",
      name: "Feral Goat Missions",
      displayName: "Feral Goat",
      animalID: "an19",
      filterArray: ["r9"], // Reservati na kojim se nalazi
      missionPackValue: "10.000gm$",
      imageURL: "https://static.thehunter.com/static/img/statistics/feral_goat.png",
      bgURL: "https://i.postimg.cc/D0mwQcPz/1f1b5a95-dc47-4c46-a519-adf8f610b606.jpg",
      missionsList: [
        {
          missionID: "m18-1",
          name: "The Usual Suspects",
          earnings: "100",
          singleplayer: false,
          sameHunt: false,
          selected: false, // da li je zavrsena misija
          passable: true,
          require: [],
          goals: [
            "ID droppings from a Feral Hog",
            "ID droppings from a Red Kangaroo",
            "ID droppings from a Feral Goat"
          ],
        },
        {
          missionID: "m18-2",
          name: "Dragnet Operation",
          earnings: "200",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "ID footprints of a Feral Goat",
            "ID footprints of a second different Feral Goat in the same hunt",
            "ID footprints of a third different Feral Goat in the same hunt",
            "ID the call of a male Feral Goat in the same hunt",
            "ID the call of a female Feral Goat in the same hunt"
          ],
        },
        {
          missionID: "m18-3",
          name: "Covert Action",
          earnings: "300",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              equipments: ["eq1", "eq2"],
              text: "Use eaither Ground Blind or Tripod Stand"
            },
          ],
          goals: [
            "Harvest a Feral Goat from a tower, Ground Blind or Tripod Stand"
          ],
        },
        {
          missionID: "m18-4",
          name: "Police Lineup",
          earnings: "400",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Spot a Feral Goat with fur variation Grey",
            "Spot a Feral Goat with fur variation Piebald",
            "Spot a Feral Goat with fur variation Piebald Black"
          ],
        },
        {
          missionID: "m18-5",
          name: "The Scapegoat",
          earnings: "600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w1", "w2"],
              text: "Use .223 Bolt Action Rifle or .223 Semi-Automatic Rifle"
            }
          ],
          goals: [
            "Harvest a fleeing Feral Goat with a single shot, using .223 ammunition"
          ],
        },
        {
          missionID: "m18-6",
          name: "Silence of the Goats",
          earnings: "800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w55", "w56", "w57", "w58"],
              text: "Recurve Bow, Heavy Recurve Bow, Longbow or Cable-backed Bow"
            }
          ],
          goals: [
            "Harvest a male Feral Goat with a Recurve Bow, Heavy Recurve Bow, Longbow or Cable-backed Bow",
            "Harvest a female Feral Goat with a Recurve Bow, Heavy Recurve Bow, Longbow or Cable-backed Bow"
          ],
        },
        {
          missionID: "m18-7",
          name: "The war on shrubs",
          earnings: "1000",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w42", "w43", "w47", "w46"],
              text:"Use .357, .44, 10mm Semi-Automatic Pistol or .308 Handgun"
            }
          ],
          goals: [
            "Harvest a Feral Goat with 100% Harvest Value, using any ethical pistol or revolver"
          ],
        },
        {
          missionID: "m18-8",
          name: "An offer you can't refuse",
          earnings: "1200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w6", "w7", "w8", "w9", "w10", "w11", "w12", "w13", "w14", "w15", "w16", "w17"],
              text: "Use any bolt action rifle"
            }
          ],
          goals: [
            "Harvest a Feral Goat with a Bolt Action Rifle from a distance of at least 120 meters, using only iron sights"
          ],
        },
        {
          missionID: "m18-9",
          name: "Collateral Damage",
          earnings: "1800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a male Feral Goat with a score of 200 or more",
            "Harvest a male Feral Goat with a score of 90 or less",
            "Harvest a female Feral Goat with a score of 150 or more",
            "Harvest a female Feral Goat with a score of 50 or less"
          ],
        },
        {
          missionID: "m18-10",
          name: "The Goatfather",
          earnings: "3600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a male Feral Goat weighing at least 60 kg with a single shot, hitting heart or lungs"
          ],
        },
      ],
    },
    {
      id: "m19",
      name: "Feral Hog Missions",
      displayName: "Feral Hog",
      animalID: "an20",
      filterArray: ["r2", "r3", "r7", "r9", "r12"], // Reservati na kojim se nalazi
      missionPackValue: "10.000gm$",
      imageURL: "https://static.thehunter.com/static/img/statistics/feral_hog.png",
      bgURL: "https://i.postimg.cc/7ZZx892Y/1962ea2d-0595-4b0e-bd3f-5396ce20c84d.jpg",
      missionsList: [
        {
          missionID: "m19-1",
          name: "On the Matter of Pigs",
          earnings: "100",
          singleplayer: false,
          sameHunt: false,
          selected: false, // da li je zavrsena misija
          passable: true,
          require: [],
          goals: [
            "Find a Feral Hog track south of the Field Lodge on Logger's Point",
            "Find a Feral Hog track south of the Middle Tower but north of the Field Lodge on Logger's Point",
            "Find a Feral Hog track north of the Middle Tower on Logger's Point"
          ],
        },
        {
          missionID: "m19-2",
          name: "Blowing in the Wind",
          earnings: "200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Feral Hog from under 45.72m (approx. 150ft.)"
          ],
        },
        {
          missionID: "m19-3",
          name: "Squealer",
          earnings: "300",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Feral Hog in the Three Lakes area in the north of Logger's Point",
            "Harvest another Feral Hog in the Three Lakes area in the north of Logger's Point during the same hunt"
          ],
        },
        {
          missionID: "m19-4",
          name: "Electric Lady Land",
          earnings: "400",
          singleplayer: true,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest 2 Feral Hogs from the pack raiding the Powerstation"
          ],
        },
        {
          missionID: "m19-5",
          name: "All Along The Watchtower",
          earnings: "600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Feral Hog from the North Hunting Tower on Logger's Point",
            "Harvest a Feral Hog from the Middle Hunting Tower on Logger's Point",
            "Harvest a Feral Hog from the South Hunting Tower on Logger's Point"
          ],
        },
        {
          missionID: "m19-6",
          name: "Unnatural Selection",
          earnings: "800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a male Feral Hog weighing more than 181.437kg (approx. 400lbs)"
          ],
        },
        {
          missionID: "m19-7",
          name: "Uninvited Guests",
          earnings: "1000",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w51"],
              text:"Use Compound Bow Snakebite"
            }
          ],
          goals: [
            "Harvest 3 Feral Hogs with the Snakebite Compound Bow in the area south of the Field Lodge on Logger's Point"
          ],
        },
        {
          missionID: "m19-8",
          name: "Eye of The Hog",
          earnings: "1200",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w8"],
              text: "Use .300 Bolt Action Rifle"
            },
            {
              weapons: ["w43"],
              text: "Use .44 Revolver"
            }
          ],
          goals: [
            "Harvest a Feral Hog using the .300 Rifle",
            "Harvest another Feral Hog using a .44 Magnum Revolver during the same hunt",
            "Harvest another Feral Hog using a shotgun with Slug ammo during the same hunt"
          ],
        },
        {
          missionID: "m19-9",
          name: "Range Finder",
          earnings: "1800",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest a Feral Hog with one shot from between 60.96 meters and 76.2 meters (approx. 200 & 250 ft.) with a scoped weapon",
            "Harvest a Feral Hog with one shot from between 91.44 meters and 106.68 meters (300 & 350 ft.) with a scoped weapon",
            "Harvest a Feral Hog with one shot from between 121.92 meters and 137.16 meters (approx. 400 & 450 ft.) with a scoped weapon"
          ],
        },
        {
          missionID: "m19-10",
          name: "God Save the Queen",
          earnings: "3600",
          singleplayer: true,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest the Feral 'Queen' Hog terrorizing Canyon Creek"
          ],
        },
      ],
    },
    {
      id: "m20",
      name: "Grey Wolf Missions",
      displayName: "Grey Wolf",
      animalID: "an22",
      filterArray: ["r11"], // Reservati na kojim se nalazi
      missionPackValue: "10.000gm$",
      imageURL: "https://static.thehunter.com/static/img/statistics/wolf.png",
      bgURL: "https://i.postimg.cc/6pvRbSnN/v5B8MaFi.jpg",
      missionsList: [
        {
          missionID: "m20-1",
          name: "On All Fours",
          earnings: "100",
          singleplayer: false,
          sameHunt: false,
          selected: false, // da li je zavrsena misija
          passable: true,
          require: [],
          goals: [
            "Identify 3 Grey Wolf tracks from the same animal",
            "Identify a call from a Grey Wolf",
            "Spot 3 Grey Wolfs"
          ],
        },
        {
          missionID: "m20-2",
          name: "Taking on the Pack",
          earnings: "200",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest 3 Grey Wolfs in the same hunt"
          ],
        },
        {
          missionID: "m20-3",
          name: "Traditional Hunting Methods",
          earnings: "300",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w51", "w52", "w53", "w54"],
              text: "Use Compound bows, Snakebite, Pulsar, Parker Python or Red Dragon"
            }
          ],
          goals: [
            "Identify droppings from a Grey Wolf",
            "Spot a Grey Wolf",
            "Harvest 2 unspooked Grey Wolfs using any Compound Bow"
          ],
        },
        {
          missionID: "m20-4",
          name: "The Capitoline Wolf",
          earnings: "400",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w59", "w60"],
              text: "Use Reverse Draw or Tenpoint Carbon Fusion Crossbow"
            }
          ],
          goals: [
            "Spot 2 male Grey Wolfs",
            "After spotting the Grey Wolves, harvest 2 male Grey Wolfs from a distance of 20 meters (Approx. 65 ft) or higher using any Crossbow",
            "Finally, harvest a female Grey Wolf with a weight of 50kg (approx. 110 lbs) or higher in Timbergold Trails using any Crossbow"
          ],
        },
        {
          missionID: "m20-5",
          name: "On the Prowl",
          earnings: "600",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              equipments: ["eq3"],
              text: "Required Tree Stand"
            }
          ],
          goals: [
            "Harvest an unspooked Grey Wolf from under 20 meters (Approx. 66 ft) while using a Tree Stand",
            "Harvest another unspooked Grey Wolf from under 12 meters (Approx. 39 ft) while using a Tree Stand"
          ],
        },
        {
          missionID: "m20-6",
          name: "Fangs like an Assassin",
          earnings: "800",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Harvest two Grey Wolves within 5 minutes of each harvest"
          ],
        },
        {
          missionID: "m20-7",
          name: "The Night Lurker, Amarok",
          earnings: "1000",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w7"],
              text:".270 Bolt Action Rifle"
            }
          ],
          goals: [
            "Harvest an unspooked male dark Grey Wolf using any .270 Bolt Action Rifle in Timbergold Trails with a shot to the heart"
          ],
        },
        {
          missionID: "m20-8",
          name: "Alpha, Beta, Omega",
          earnings: "1200",
          singleplayer: false,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w59", "w60"],
              text: "Use Reverse Draw or Tenpoint Carbon Fusion Crossbow"
            },
            {
              weapons: ["w51", "w52", "w53", "w54"],
              text: "Use any Compound bow: Snakebite, Pulsar, Parker Python or Red Dragon"
            },
            {
              weapons: ["w7"],
              text: "Use .270 Bolt Action Rifle"
            },
          ],
          goals: [
            "Harvest a male Grey Wolf with a weight of 65kg (approx. 143 lbs) or higher in one shot",
            "Harvest a female Grey Wolf with a weight of 40kg (approx. 88 lbs) or higher in one shot",
            "Harvest a Grey Wolf with a lung shot using any Crossbow",
            "Harvest a Grey Wolf with a lung shot using any Compound Bow",
            "Harvest a Grey Wolf with a lung shot using any .270 Bolt Action Rifle",
            "Harvest an unspooked Grey Wolf with a heart shot. Other organs may be hit"
          ],
        },
        {
          missionID: "m20-9",
          name: "The Remaining Followers",
          earnings: "1800",
          singleplayer: false,
          sameHunt: true,
          selected: false,
          passable: true,
          require: [
            {
              weapons: ["w42", "w43", "w47", "w46", "w50"],
              text:"Use .357, .44, 10mm Semi-Automatic Pistol or .308 Handgun or .50 Muzzleloading pistol"
            }
          ],
          goals: [
            "Harvest an unspooked common Grey Wolf from under 20 meters (Approx. 66 ft) in the same hunt",
            "Harvest a dark Grey Wolf in one shot in the same hunt",
            "Harvest a brown Grey Wolf with any ethical handgun from over 35 meters (Approx. 115 ft) in the same hunt"
          ],
        },
        {
          missionID: "m20-10",
          name: "The Legendary Fenrir",
          earnings: "3600",
          singleplayer: true,
          sameHunt: false,
          selected: false,
          passable: true,
          require: [],
          goals: [
            "Identify a call from a Grey Wolf",
            "Harvest the dark Grey Wolf Fenrir by Brimstone (X: -7.140, Y: -156) in Timbergold Trails"
          ],
        },
      ],
    },
  ])

  function selectMission(id, packName) {
    missions.value.forEach(missionPack => {
      if(missionPack.displayName === packName){
        missionPack.missionsList.forEach(mission => {
          if(mission.missionID === id){
            mission.selected = !mission.selected
          }
        })
      }
    })
  }
  
  return { missions, selectMission }
})
